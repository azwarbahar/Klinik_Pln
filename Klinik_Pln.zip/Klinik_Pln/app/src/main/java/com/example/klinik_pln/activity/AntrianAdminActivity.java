package com.example.klinik_pln.activity;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.viewpager.widget.ViewPager;

import android.app.ProgressDialog;
import android.os.Bundle;
import android.widget.CompoundButton;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import com.example.klinik_pln.R;
import com.example.klinik_pln.adapter.ViewPagerAntrianAdapter;
import com.example.klinik_pln.fragment.AllAntrianFragment;
import com.example.klinik_pln.fragment.DoneFragment;
import com.example.klinik_pln.fragment.MenungguFragment;
import com.example.klinik_pln.model.AntrianModel;
import com.example.klinik_pln.model.BukaAntrianModel;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.material.tabs.TabLayout;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

public class AntrianAdminActivity extends AppCompatActivity {

    private TabLayout tab_antrian;
    private ViewPager pager_antrian;
    private ViewPagerAntrianAdapter adapter;
    private TextView tv_tanggal;
    private Switch simpleSwitch;

    ProgressDialog pd;


    private String getStatus = "";
    private String nomorBaru = "0";

    DatabaseReference database;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_antrian_admin);

        androidx.appcompat.widget.Toolbar mTopToolbar = findViewById(R.id.toolbar);
        setSupportActionBar(mTopToolbar);


        simpleSwitch = findViewById(R.id.simpleSwitch);
        tab_antrian = findViewById(R.id.tab_antrian);
        pager_antrian = findViewById(R.id.pager_antrian);
        adapter = new ViewPagerAntrianAdapter(getSupportFragmentManager());
        pd = new ProgressDialog(this);
        database = FirebaseDatabase.getInstance().getReference();
        updateSwitch();
        simpleSwitch.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (simpleSwitch.isChecked()){
                    simpleSwitch.setText("Buka");
                    database.child("Aktivitas").child("status").setValue("Buka");

                } else if (!simpleSwitch.isChecked()){
                    simpleSwitch.setText("Tutup");
                    database.child("Aktivitas").child("status").setValue("Tutup");
                    resetNomor(new AntrianModel(nomorBaru));
                }

                updateSwitch();
            }
        });


        adapter.AddFragment(new MenungguFragment(),"Menunggu");
        adapter.AddFragment(new DoneFragment(),"Selesai");
        adapter.AddFragment(new AllAntrianFragment(),"Riwayat");
        pager_antrian.setAdapter(adapter);
        tab_antrian.setupWithViewPager(pager_antrian);
        tv_tanggal = findViewById(R.id.tv_tanggal);
        DateFormat dateFormat = new SimpleDateFormat("EEEE, dd MMMM yyyy");
        Date date = new Date();
        tv_tanggal.setText(dateFormat.format(date));


    }

    private void resetNomor(AntrianModel antrianModel){
        database.child("Antrian").setValue(antrianModel).addOnSuccessListener(this, new OnSuccessListener<Void>() {
            @Override
            public void onSuccess(Void aVoid) {
                Toast.makeText(AntrianAdminActivity.this, "Perbarui Nomor Antrian", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void updateSwitch(){
        pd.setMessage("Proses ... ");
        pd.setCancelable(true);
        pd.show();

        Query query = database.child("Aktivitas").limitToLast(1);
        query.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                getStatus = dataSnapshot.child("status").getValue().toString();

                if (getStatus.equals("Buka")){
                    simpleSwitch.setChecked(true);
                    simpleSwitch.setText("Buka");
                    database.child("Aktivitas").child("status").setValue("Buka");
                } else if (getStatus.equals("Tutup")){
                    simpleSwitch.setChecked(false);
                    simpleSwitch.setText("Tutup");
                    database.child("Aktivitas").child("status").setValue("Tutup");
                }

                pd.hide();
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                pd.hide();
            }
        });
    }
}
