package com.example.klinik_pln.activity;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.app.ProgressDialog;
import android.os.Bundle;
import android.widget.Toast;

import com.example.klinik_pln.R;
import com.example.klinik_pln.adapter.AbsenDokterAdapter;
import com.example.klinik_pln.api.ApiRequestDoketr;
import com.example.klinik_pln.api.RetroServerDokter;
import com.example.klinik_pln.model.DokterModel;
import com.example.klinik_pln.model.ResponsModelTambah;

import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class CekDokterActivity extends AppCompatActivity {

    private RecyclerView rv_dokter;

    private List<DokterModel> modelList;
    private ProgressDialog pd;
    private RecyclerView.Adapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cek_dokter);

        androidx.appcompat.widget.Toolbar mTopToolbar = findViewById(R.id.toolbar);
        setSupportActionBar(mTopToolbar);

        rv_dokter = findViewById(R.id.rv_dokter);

        pd = new ProgressDialog(this);

        readDokterabsen();

    }

    private void readDokterabsen(){
        pd.setMessage("Proses ... ");
        pd.setCancelable(false);
        pd.show();
        ApiRequestDoketr apiRequestDoketr = RetroServerDokter.getClient().create(ApiRequestDoketr.class);
        Call<ResponsModelTambah> getabsenDokter = apiRequestDoketr.getabsenDokter();
        getabsenDokter.enqueue(new Callback<ResponsModelTambah>() {
            @Override
            public void onResponse(Call<ResponsModelTambah> call, Response<ResponsModelTambah> response) {
                pd.hide();
                String kode = response.body().getKode();
                if (kode.equals("1")){
                    modelList = response.body().getResultAbsenDokter();
                    rv_dokter.setLayoutManager(new LinearLayoutManager(CekDokterActivity.this));
                    adapter = new AbsenDokterAdapter(CekDokterActivity.this, modelList);
                    rv_dokter.setAdapter(adapter);
                }
            }

            @Override
            public void onFailure(Call<ResponsModelTambah> call, Throwable t) {
                pd.hide();
            }
        });
    }
}
