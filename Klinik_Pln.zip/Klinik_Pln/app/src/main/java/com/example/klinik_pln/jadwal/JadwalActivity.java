package com.example.klinik_pln.jadwal;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.example.klinik_pln.R;

public class JadwalActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_jadwal);
    }


}