package com.example.klinik_pln.api;

public class Url_IP {

    final static String ALAMAT_IP = "http://192.168.1.10/";
//    final static String ALAMAT_IP = "https://poliklinikpln.000webhostapp.com/";
}
