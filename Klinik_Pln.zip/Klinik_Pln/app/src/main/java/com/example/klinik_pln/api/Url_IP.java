package com.example.klinik_pln.api;

public class Url_IP {

    final static String ALAMAT_IP = "http://192.168.43.188/";
//    final static String ALAMAT_IP = "http://192.168.137.1/";
}
