package com.example.klinik_pln.activity;

import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.example.klinik_pln.R;
import com.example.klinik_pln.api.ApiRequestUser;
import com.example.klinik_pln.api.RetroServerUser;
import com.example.klinik_pln.model.GetDataUserModel;
import com.example.klinik_pln.model.ResponsModelTambah;

import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class RegisterActivity extends AppCompatActivity {
    private EditText et_fullnama,et_alamat,et_telpon,et_username,et_password;

    private String jekel = "-";
    private String level = "pasien";
    private TextView tv_login;
    private ProgressDialog pd;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        et_fullnama = findViewById(R.id.et_fullnama);
        et_alamat = findViewById(R.id.et_alamat);
        et_telpon = findViewById(R.id.et_telpon);
        et_username = findViewById(R.id.et_username);
        et_password = findViewById(R.id.et_password);


        tv_login = findViewById(R.id.tv_login);

        tv_login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(RegisterActivity.this, LoginActivity.class);
                startActivity(intent);
            }
        });

        pd = new ProgressDialog(this);

        Button btn_register = findViewById(R.id.btn_register);
        btn_register.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                pd.setMessage("Proses ... ");
                pd.setCancelable(false);
                pd.show();

                String username_cek = et_username.getText().toString();

                final ApiRequestUser apiRequestUser = RetroServerUser.getClient().create(ApiRequestUser.class);

                Call<List<GetDataUserModel>> getcekdata = apiRequestUser.getdatauser(username_cek);

                getcekdata.enqueue(new Callback<List<GetDataUserModel>>() {
                    @Override
                    public void onResponse(Call<List<GetDataUserModel>> call, Response<List<GetDataUserModel>> response) {
                        pd.hide();

                        if (response.isSuccessful()){
                            assert response.body() != null;
                            if (!response.body().isEmpty()){

                                Toast.makeText(RegisterActivity.this, "Username Sudah Digunakan ...", Toast.LENGTH_SHORT).show();

                            } else {

                                String nama = et_fullnama.getText().toString();
                                String alamat = et_alamat.getText().toString();
                                String telpon = et_telpon.getText().toString();
                                String user = et_username.getText().toString();
                                String pass = et_password.getText().toString();

                                Call<ResponsModelTambah> senduser = apiRequestUser.sendUser(nama,alamat,telpon,jekel,user,pass,level);
                                senduser.enqueue(new Callback<ResponsModelTambah>() {
                                    @Override
                                    public void onResponse(Call<ResponsModelTambah> call, Response<ResponsModelTambah> response) {
//                        pd.hide();
                                        Log.d("RETRO", "response : " + response.body().toString());
                                        String kode = response.body().getKode();

                                        if (kode.equals("1")){
                                            Toast.makeText(RegisterActivity.this, "Berhasil Registrasi", Toast.LENGTH_SHORT).show();

                                            et_alamat.setText("");
                                            et_fullnama.setText("");
                                            et_password.setText("");
                                            et_telpon.setText("");
                                            et_username.setText("");

                                        } else {
                                            Toast.makeText(RegisterActivity.this, "Data Error, Tidak Berhasil Registrasi", Toast.LENGTH_SHORT).show();
                                        }
                                    }

                                    @Override
                                    public void onFailure(Call<ResponsModelTambah> call, Throwable t) {
                                        pd.hide();
                                        Log.d("RETRO", "Falure : " + "Gagal Mengirim Request");
                                    }
                                });

                            }
                        }
                    }

                    @Override
                    public void onFailure(Call<List<GetDataUserModel>> call, Throwable t) {

                    }
                });





            }
        });
    }
}
