package com.example.klinik_pln.model;

public class AntrianLastDoneModel {
    private String kode_antrian;

    public AntrianLastDoneModel(String kode_antrian) {
        this.kode_antrian = kode_antrian;
    }

    public String getKode_antrian() {
        return kode_antrian;
    }

    public void setKode_antrian(String kode_antrian) {
        this.kode_antrian = kode_antrian;
    }
}
