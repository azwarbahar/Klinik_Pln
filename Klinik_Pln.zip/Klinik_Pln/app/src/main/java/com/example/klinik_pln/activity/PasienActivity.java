package com.example.klinik_pln.activity;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.example.klinik_pln.R;
import com.example.klinik_pln.api.ApiRequestAntrian;
import com.example.klinik_pln.api.RetroServerAntrian;
import com.example.klinik_pln.model.AntrianLastDoneModel;
import com.example.klinik_pln.model.AntrianModel;
import com.example.klinik_pln.model.ResponsModelTambah;
import com.example.klinik_pln.model.getDataAntrianOneModel;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class PasienActivity extends AppCompatActivity {

    DatabaseReference database;

    private String GET_NAMA = "get_nama";
    private String GET_LEVEL = "get_level";
    private String GET_ALAMAT = "get_alamat";
    private String GET_TELPON = "get_telpon";
    private String GET_JEKEL = "get_jekel";
    private String GET_USER = "get_user";
    private String GET_PASS = "get_pass";

    //kirim data ke cek nomor antrian
    private String GET_KODE = "get_kode";
    private String GET_PERIKSA = "get_periksa";
    private String GET_TGL = "get_tgl";
    private String GET_JAM = "get_jam";

    TextView nama_lengkap;
    TextView no_telpon;
    TextView tv_no_antrian;
    TextView tv_no_periksa;
    TextView tanggal;
    TextView jam;
    Button btn_ambilnomor, btn_ceknomor, btn_lokasi,btn_cek_dokter;

    private String nama;
    private String alamat;
    private String telpon;
    private String jekel;
    private String username;
    private String password;
    private String level;


    private String kode_sekarang;
    private String tgl_antrian;
    private String jam_antrian;

    //variabel realtime
    private String nol = "";
    private String kode = "PS";
    private String nomor_tampil = "";
    private String nomor_final = "";

    private String status_nomor = "";
    private List<AntrianLastDoneModel> antrianLastDoneModels;

    private String getStatusKlini = "";

    private Handler handler = new Handler();

    ProgressDialog pd;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pasien);

        handler.postDelayed(runnable, 1000);
        nama_lengkap = findViewById(R.id.nama_lengkap);
        no_telpon = findViewById(R.id.no_telpon);
        btn_ambilnomor = findViewById(R.id.btn_ambilnomor);
        btn_ceknomor = findViewById(R.id.btn_ceknomor);
        btn_lokasi = findViewById(R.id.btn_lokasi);
        btn_cek_dokter = findViewById(R.id.btn_cek_dokter);
        tv_no_antrian = findViewById(R.id.tv_no_antrian);
        tv_no_periksa = findViewById(R.id.tv_no_periksa);
        tanggal = findViewById(R.id.tanggal);
        jam = findViewById(R.id.jam);
        pd = new ProgressDialog(this);
        getBundle();

        btn_cek_dokter.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(PasienActivity.this, CekDokterActivity.class);
                startActivity(intent);
            }
        });


        database = FirebaseDatabase.getInstance().getReference();

        btn_ceknomor.setOnClickListener(new View.OnClickListener() {
            @SuppressLint("ResourceAsColor")
            @Override
            public void onClick(View v) {

                if (status_nomor.equals("mati")) {
                    Toast.makeText(PasienActivity.this, "Anda belum Mengambil Antrian", Toast.LENGTH_SHORT).show();
                } else {
                    Bundle bundle = new Bundle();
                    bundle.putString(GET_KODE, kode_sekarang);
                    bundle.putString(GET_PERIKSA, (String) tv_no_periksa.getText());
                    bundle.putString(GET_TGL, tgl_antrian);
                    bundle.putString(GET_JAM, jam_antrian);
                    Intent intent = new Intent(PasienActivity.this, CekAntrianActivity.class);
                    intent.putExtras(bundle);
                    startActivity(intent);
                }


            }
        });

        btn_ambilnomor.setOnClickListener(new View.OnClickListener() {
            @SuppressLint("ResourceAsColor")
            @Override
            public void onClick(View v) {

                ApiRequestAntrian apiRequestAntrian = RetroServerAntrian.getClient().create(ApiRequestAntrian.class);
                Call<ResponsModelTambah> sendAntrian = apiRequestAntrian.sendDataAntrian(tv_no_antrian.getText().toString(), nama, tanggal.getText().toString(), jam.getText().toString(), "Tunggu");
                sendAntrian.enqueue(new Callback<ResponsModelTambah>() {
                    @Override
                    public void onResponse(Call<ResponsModelTambah> call, Response<ResponsModelTambah> response) {

                        Log.d("RETRO", "response : " + response.body().toString());
                        String kode_pest = response.body().getKode();
                        if (kode_pest.equals("1")) {
                            submitAntrian(new AntrianModel(nomor_final));
                            updateNomor();
                            btn_ambilnomor.setEnabled(false);
                            btn_ambilnomor.setBackgroundResource(R.drawable.bg_btn_mati);
                            cekStatus();
                        } else {
                            updateNomor();
                            cekStatus();
                        }

                    }

                    @Override
                    public void onFailure(Call<ResponsModelTambah> call, Throwable t) {

                    }
                });
                cekStatus();
            }
        });

        btn_lokasi.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(PasienActivity.this, JalanApotekActivity.class);
                startActivity(intent);
            }
        });
        DateFormat dateFormat = new SimpleDateFormat("EEEE, dd MMMM yyyy");
        Date date = new Date();
        tanggal.setText(dateFormat.format(date));
        cekStatus();
        updateNomorRefresh();


    }

    private void periksaTerakhir() {
        ApiRequestAntrian apiRequestAntrian = RetroServerAntrian.getClient().create(ApiRequestAntrian.class);
        Call<ResponsModelTambah> getdatalasDone = apiRequestAntrian.getdatalastDone();
        getdatalasDone.enqueue(new Callback<ResponsModelTambah>() {
            @Override
            public void onResponse(Call<ResponsModelTambah> call, Response<ResponsModelTambah> response) {

                String kode = response.body().getKode();
                if (kode.equals("1")) {
                    antrianLastDoneModels = response.body().getResultLastDone();
                    for (int a = 0; a < antrianLastDoneModels.size(); a++) {
                        tv_no_periksa.setText(antrianLastDoneModels.get(a).getKode_antrian());
                    }
                } else {
                    Toast.makeText(PasienActivity.this, "Kode : " + kode, Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(Call<ResponsModelTambah> call, Throwable t) {

            }
        });
    }

    private void cekStatus() {

        ApiRequestAntrian apiRequestAntrian = RetroServerAntrian.getClient().create(ApiRequestAntrian.class);
        Call<List<getDataAntrianOneModel>> getantrianstatus = apiRequestAntrian.getSingleData(nama, tanggal.getText().toString(), "Tunggu");
        getantrianstatus.enqueue(new Callback<List<getDataAntrianOneModel>>() {
            @Override
            public void onResponse(Call<List<getDataAntrianOneModel>> call, Response<List<getDataAntrianOneModel>> response) {

                if (response.isSuccessful()) {

                    assert response.body() != null;
                    if (!response.body().isEmpty()) {
                        for (int i = 0; i < response.body().size(); i++) {
                            kode_sekarang = response.body().get(i).getKode_antrian();
                            tgl_antrian = response.body().get(i).getTanggal_antrian();
                            jam_antrian = response.body().get(i).getJam_antrian();


                            btn_ambilnomor.setEnabled(false);
                            btn_ambilnomor.setBackgroundResource(R.drawable.bg_btn_mati);
                            status_nomor = "aktif";
                        }
                    } else {
                        btn_ambilnomor.setEnabled(true);
                        btn_ambilnomor.setBackgroundResource(R.drawable.bg_btn_terang);
                        status_nomor = "mati";
                    }
                }

            }

            @Override
            public void onFailure(Call<List<getDataAntrianOneModel>> call, Throwable t) {

            }
        });
    }

    private void cekStatusskali() {

        ApiRequestAntrian apiRequestAntrian = RetroServerAntrian.getClient().create(ApiRequestAntrian.class);
        Call<List<getDataAntrianOneModel>> getantrianstatus = apiRequestAntrian.getSingleData(nama, tanggal.getText().toString(), "Tunggu");
        getantrianstatus.enqueue(new Callback<List<getDataAntrianOneModel>>() {
            @Override
            public void onResponse(Call<List<getDataAntrianOneModel>> call, Response<List<getDataAntrianOneModel>> response) {

                if (response.isSuccessful()) {

                    assert response.body() != null;
                    if (!response.body().isEmpty()) {
                        for (int i = 0; i < response.body().size(); i++) {
                            kode_sekarang = response.body().get(i).getKode_antrian();
                            tgl_antrian = response.body().get(i).getTanggal_antrian();
                            jam_antrian = response.body().get(i).getJam_antrian();


                            btn_ambilnomor.setEnabled(false);
                            btn_ambilnomor.setBackgroundResource(R.drawable.bg_btn_mati);
                            status_nomor = "aktif";
                        }
                    } else {
                        btn_ambilnomor.setEnabled(true);
                        btn_ambilnomor.setBackgroundResource(R.drawable.bg_btn_terang);
                        status_nomor = "mati";
                    }
                }

            }

            @Override
            public void onFailure(Call<List<getDataAntrianOneModel>> call, Throwable t) {

            }
        });
    }

    private void updateNomor() {

        Query query = database.child("Antrian").limitToLast(1);
        query.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {

                nomor_final = dataSnapshot.child("nomor_antrian").getValue().toString();
                int a = Integer.parseInt(nomor_final) + 1;
                nomor_final = String.valueOf(a);
                if (nomor_final.length() == 1) {
                    nol = "00";
                } else if (nomor_final.length() == 2) {
                    nol = "0";
                } else if (nomor_final.length() == 3) {
                    nol = "";
                }

                nomor_tampil = kode + nol + nomor_final;
                tv_no_antrian.setText(nomor_tampil);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
    }

    private void updateNomorRefresh() {
        pd.setMessage("Proses ... ");
        pd.setCancelable(true);
        pd.show();
        Query query = database.child("Antrian").limitToLast(1);
        query.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {

                nomor_final = dataSnapshot.child("nomor_antrian").getValue().toString();
                int a = Integer.parseInt(nomor_final) + 1;
                nomor_final = String.valueOf(a);
                if (nomor_final.length() == 1) {
                    nol = "00";
                } else if (nomor_final.length() == 2) {
                    nol = "0";
                } else if (nomor_final.length() == 3) {
                    nol = "";
                }

                nomor_tampil = kode + nol + nomor_final;
                tv_no_antrian.setText(nomor_tampil);

                pd.hide();
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
    }

    private void statusBukaKlini(){
        Query query = database.child("Aktivitas").limitToLast(1);
        query.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                getStatusKlini = dataSnapshot.child("status").getValue().toString();
                if (getStatusKlini.equals("Tutup")){
                    btn_ambilnomor.setEnabled(false);
                    btn_ambilnomor.setBackgroundResource(R.drawable.bg_btn_mati);
                    btn_ambilnomor.setText("Klinik Tutup");
                } else if (getStatusKlini.equals("Buka")){
                    btn_ambilnomor.setEnabled(true);
                    btn_ambilnomor.setText("Ambil Nomor");
                    cekStatus();
                }

                pd.hide();
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                pd.hide();
            }
        });
    }


    private Runnable runnable = new Runnable() {
        @Override
        public void run() {
            statusBukaKlini();
            updateNomor();

            if (tv_no_antrian.getText().toString().equals("PS001")){
                tv_no_periksa.setText("PS000");
            } else {
                periksaTerakhir();
            }


            DateFormat timeFormat = new SimpleDateFormat("HH:mm:ss");
            Date date = new Date();
            jam.setText(timeFormat.format(date));

            handler.postDelayed(this, 1000);
        }
    };


    private void submitAntrian(AntrianModel antrianModel) {

        pd.setMessage("Proses ... ");
        pd.setCancelable(true);
        pd.show();

        database.child("Antrian").setValue(antrianModel).addOnSuccessListener(this, new OnSuccessListener<Void>() {
            @Override
            public void onSuccess(Void aVoid) {

                pd.hide();

            }
        });
    }


    private void getBundle() {

        Bundle bundle = getIntent().getExtras();
        assert bundle != null;

        nama = bundle.getString(GET_NAMA);
        alamat = bundle.getString(GET_ALAMAT);
        telpon = bundle.getString(GET_TELPON);
        jekel = bundle.getString(GET_JEKEL);
        username = bundle.getString(GET_USER);
        password = bundle.getString(GET_PASS);
        level = bundle.getString(GET_LEVEL);
        nama_lengkap.setText(nama);
        no_telpon.setText(telpon);
    }
}
