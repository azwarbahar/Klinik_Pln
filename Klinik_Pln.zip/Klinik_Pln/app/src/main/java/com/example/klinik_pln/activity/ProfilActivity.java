package com.example.klinik_pln.activity;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.example.klinik_pln.R;

public class ProfilActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profil);
    }
}
