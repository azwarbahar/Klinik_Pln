package com.example.klinik_pln.model;

import android.os.Parcel;
import android.os.Parcelable;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class GetDataUserModel implements Parcelable {

    @SerializedName("nama_user")
    @Expose
    private String  nama;

    @SerializedName("alamat_user")
    @Expose
    private String alamat;

    @SerializedName("telepon_user")
    @Expose
    private String telpon;

    @SerializedName("jekel_user")
    @Expose
    private String jekel;

    @SerializedName("username_user")
    @Expose
    private String username_user;

    @SerializedName("password_user")
    @Expose
    private String password;

    @SerializedName("level_user")
    @Expose
    private String level;


    public GetDataUserModel(String nama, String alamat, String telpon, String jekel, String username, String password, String level) {
        this.nama = nama;
        this.alamat = alamat;
        this.telpon = telpon;
        this.jekel = jekel;
        this.username_user = username;
        this.password = password;
        this.level = level;
    }

    protected GetDataUserModel(Parcel in) {
        nama = in.readString();
        alamat = in.readString();
        telpon = in.readString();
        jekel = in.readString();
        username_user = in.readString();
        password = in.readString();
        level = in.readString();
    }

    public static final Creator<GetDataUserModel> CREATOR = new Creator<GetDataUserModel>() {
        @Override
        public GetDataUserModel createFromParcel(Parcel in) {
            return new GetDataUserModel(in);
        }

        @Override
        public GetDataUserModel[] newArray(int size) {
            return new GetDataUserModel[size];
        }
    };

    public String getNama() {
        return nama;
    }

    public void setNama(String nama) {
        this.nama = nama;
    }

    public String getAlamat() {
        return alamat;
    }

    public void setAlamat(String alamat) {
        this.alamat = alamat;
    }

    public String getTelpon() {
        return telpon;
    }

    public void setTelpon(String telpon) {
        this.telpon = telpon;
    }

    public String getJekel() {
        return jekel;
    }

    public void setJekel(String jekel) {
        this.jekel = jekel;
    }

    public String getUsername_user() {
        return username_user;
    }

    public void setUsername_user(String username_user) {
        this.username_user = username_user;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getLevel() {
        return level;
    }

    public void setLevel(String level) {
        this.level = level;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(nama);
        dest.writeString(alamat);
        dest.writeString(telpon);
        dest.writeString(jekel);
        dest.writeString(username_user);
        dest.writeString(password);
        dest.writeString(level);
    }
}
