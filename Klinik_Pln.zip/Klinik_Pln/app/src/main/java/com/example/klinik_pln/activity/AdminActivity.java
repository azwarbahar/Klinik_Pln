package com.example.klinik_pln.activity;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.example.klinik_pln.R;
import com.example.klinik_pln.klinik.KlinikAdminActivity;

public class AdminActivity extends AppCompatActivity {

    private String GET_NAMA = "get_nama";
    private String GET_LEVEL = "get_level";
    private String GET_ALAMAT = "get_alamat";
    private String GET_TELPON = "get_telpon";
    private String GET_JEKEL = "get_jekel";
    private String GET_USER = "get_user";
    private String GET_PASS = "get_pass";
    TextView nama_lengkap;
    TextView no_telpon;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin);


        nama_lengkap = findViewById(R.id.nama_lengkap);
        no_telpon = findViewById(R.id.no_telpon);
        LinearLayout ll_pasien = findViewById(R.id.ll_pasien);
        LinearLayout ll_klinik = findViewById(R.id.ll_klinik);
        LinearLayout ll_dokter = findViewById(R.id.ll_dokter);
        LinearLayout ll_admin = findViewById(R.id.ll_admin);
        LinearLayout ll_antrian = findViewById(R.id.ll_antrian);

        ll_admin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(AdminActivity.this, AdminAdminActivity.class);
                startActivity(intent);
            }
        });

        ll_antrian.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent = new Intent(AdminActivity.this, AntrianAdminActivity.class);
                startActivity(intent);

            }
        });

        ll_pasien.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(AdminActivity.this, PasienAdminActivity.class);
                startActivity(intent);
            }
        });

        ll_dokter.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(AdminActivity.this, DokterAdminActivity.class);
                startActivity(intent);
            }
        });

        ll_klinik.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(AdminActivity.this, KlinikAdminActivity.class);
                startActivity(intent);
            }
        });

        getBundle();

    }


    private void getBundle() {

        Bundle bundle = getIntent().getExtras();
        assert bundle != null;

        String nama = bundle.getString(GET_NAMA);
        String alamat = bundle.getString(GET_ALAMAT);
        String telpon = bundle.getString(GET_TELPON);
        String jekel = bundle.getString(GET_JEKEL);
        String username = bundle.getString(GET_USER);
        String password = bundle.getString(GET_PASS);
        String level = bundle.getString(GET_LEVEL);

        nama_lengkap.setText(nama);
        no_telpon.setText(telpon);
    }
}
