package com.example.klinik_pln.adapter;

import android.app.ProgressDialog;
import android.content.Context;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.klinik_pln.R;
import com.example.klinik_pln.api.ApiRequestAntrian;
import com.example.klinik_pln.api.RetroServerAntrian;
import com.example.klinik_pln.fragment.MenungguFragment;
import com.example.klinik_pln.model.GetDataUserModel;
import com.example.klinik_pln.model.ResponsModelTambah;
import com.example.klinik_pln.model.getDataAntrianOneModel;

import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class AntrianAdapter extends RecyclerView.Adapter<AntrianAdapter.MyHolderView> {

    ProgressDialog pd;

    private Context mContext;
    private List<getDataAntrianOneModel> modelList;

    public AntrianAdapter(Context mContext, List<getDataAntrianOneModel> modelList) {
        this.mContext = mContext;
        this.modelList = modelList;
    }

    @NonNull
    @Override
    public MyHolderView onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view ;
        view = LayoutInflater.from(mContext).inflate(R.layout.item_antrian, parent,false);
        MyHolderView myHolderView = new MyHolderView(view);
        return myHolderView;
    }

    @Override
    public void onBindViewHolder(@NonNull final MyHolderView holder, final int position) {

        holder.tv_nomor.setText(modelList.get(position).getKode_antrian());
        holder.tv_nama.setText(modelList.get(position).getNama_pasien());
        final String tgl = modelList.get(position).getTanggal_antrian();

        if (modelList.get(position).getStatus().equals("Done")){
            holder.tv_panggil.setVisibility(View.GONE);
        } else {
            holder.tv_panggil.setVisibility(View.VISIBLE);

            holder.tv_panggil.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {

                    pd.setMessage("Proses ... ");
                    pd.setCancelable(false);
                    pd.show();

                    ApiRequestAntrian apiRequestAntrian = RetroServerAntrian.getClient().create(ApiRequestAntrian.class);
                    Call<ResponsModelTambah> updateStatus = apiRequestAntrian.updateData(holder.tv_nomor.getText().toString(),tgl,"Done");
                    updateStatus.enqueue(new Callback<ResponsModelTambah>() {
                        @Override
                        public void onResponse(Call<ResponsModelTambah> call, Response<ResponsModelTambah> response) {
                            pd.hide();
                            Log.d("RETRO", "response : " + response.body().toString());
                            String kode = response.body().getKode();
                            if (kode.equals("1")){
                                modelList.remove(position);
                                notifyItemRemoved(position);
                                notifyItemRangeChanged(position,modelList.size());
                            }else {
                            }
                        }

                        @Override
                        public void onFailure(Call<ResponsModelTambah> call, Throwable t) {

                            pd.hide();
                        }
                    });

                }
            });

        }


    }

    @Override
    public int getItemCount() {
        return modelList.size();
    }

    public class MyHolderView extends RecyclerView.ViewHolder {

        private TextView tv_nomor, tv_nama, tv_panggil;
        public MyHolderView(@NonNull View itemView) {
            super(itemView);

            pd = new  ProgressDialog(mContext);
            tv_nomor = itemView.findViewById(R.id.tv_nomor);
            tv_nama = itemView.findViewById(R.id.tv_nama);
            tv_panggil = itemView.findViewById(R.id.tv_panggil);
        }
    }
}
