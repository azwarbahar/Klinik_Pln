package com.example.klinik_pln.model;

public class BukaAntrianModel {

    private String status;

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public BukaAntrianModel(String status) {
        this.status = status;
    }
}
