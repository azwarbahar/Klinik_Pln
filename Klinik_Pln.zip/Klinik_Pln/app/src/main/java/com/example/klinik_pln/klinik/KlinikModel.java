package com.example.klinik_pln.klinik;

import android.os.Parcel;
import android.os.Parcelable;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class KlinikModel implements Parcelable {

    protected KlinikModel(Parcel in) {
        id = in.readString();
        nama = in.readString();
        lokasi = in.readString();
    }

    public static final Creator<KlinikModel> CREATOR = new Creator<KlinikModel>() {
        @Override
        public KlinikModel createFromParcel(Parcel in) {
            return new KlinikModel(in);
        }

        @Override
        public KlinikModel[] newArray(int size) {
            return new KlinikModel[size];
        }
    };

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getNama() {
        return nama;
    }

    public void setNama(String nama) {
        this.nama = nama;
    }

    public String getLokasi() {
        return lokasi;
    }

    public void setLokasi(String lokasi) {
        this.lokasi = lokasi;
    }

    @SerializedName("id_klinik")
    @Expose
    private String id;
    @SerializedName("nama_klinik")
    @Expose
    private String nama;
    @SerializedName("lokasi_klinik")
    @Expose
    private String lokasi;

    public KlinikModel(String id, String nama, String lokasi) {
        this.id = id;
        this.nama = nama;
        this.lokasi = lokasi;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(id);
        dest.writeString(nama);
        dest.writeString(lokasi);
    }
}
